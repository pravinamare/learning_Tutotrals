package assignment4_TestNGTestCases;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PayBills {
		
		public WebDriver driver;
		
		//SetUp (Launch the Browser and enter URL)=================
		
	@BeforeClass(alwaysRun= true)
	public void setUp() {
		
		// Set System path for browser driver
		System.setProperty("webdriver.chrome.driver" , "C:\\SeleniumBrowserDrive\\chromedriver.exe");
		
		//Open Browser
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	
		//Open url
		driver.get("http://zero.webappsecurity.com/");
			
		assertEquals(driver.getTitle(),"Zero - Personal Banking - Loans - Credit Cards");
		
		}
		
		//Login into Application=========================
				
		@BeforeMethod(alwaysRun= true)
		public void LogIn() {
			
				driver.findElement(By.id("signin_button")).click();    
				driver.findElement(By.name("user_login")).sendKeys("username");  
				driver.findElement(By.id("user_password")).sendKeys("password"); 
			
				driver.findElement(By.name("submit")).click();
				
		}
		
		//Test=======================
		//Pay bill >> Purchase foreign currency >> Handle  Alert pop-UP
		
		@Test(groups= {"Smoke"})
		public void test1() {
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.id("proceed-link")).click();
			assertEquals(driver.getTitle(),"Zero - Account Summary");
		
		driver.findElement(By.linkText("Pay Bills")).click();
		
		//ExplicitWait
		WebDriverWait ewait1 = new WebDriverWait(driver, 10);
		ewait1.until(ExpectedConditions.urlMatches("http://zero.webappsecurity.com/bank/pay-bills.html"));

		driver.findElement(By.linkText("Purchase Foreign Currency")).click();
		
		WebDriverWait ewait2 = new WebDriverWait(driver, 10);
		ewait2.until(ExpectedConditions.textToBe(By.xpath("(//h2[contains(text(),'Purchase foreign currency cash')])"), "Purchase foreign currency cash"));
		
		driver.findElement(By.xpath("//input[contains(@id,'purchase_cash')]")).click();
		Alert webAppSecurityAlert = driver.switchTo().alert();
		String alertText = webAppSecurityAlert.getText();
		System.out.println("the text on the webAppSecurityAlert is---" + "'"+ alertText + "'");
		webAppSecurityAlert.accept();
				
		}

		
		@Test(groups= {"Smoke"}) 
		public void test2() {

			driver.findElement(By.linkText("Pay Bills")).click();
			assertEquals(driver.getTitle(),"Zero - Pay Bills");

			driver.findElement(By.linkText("Purchase Foreign Currency")).click(); 
			
			WebElement currency = driver.findElement(By.id("pc_currency"));
			Select sel = new Select(currency);
			sel.selectByVisibleText("Switzerland (franc)");
			
			WebElement Amount = driver.findElement(By.id("pc_amount"));
			Amount.sendKeys("22");
			
			WebElement radiobutton = driver.findElement(By.id("pc_inDollars_false"));
			boolean drbIsselected = radiobutton.isSelected();
			if(!drbIsselected) {
				radiobutton.click();
				System.out.println("Currency radio button was not selected. I have Selcted now!");
			}
			
			WebElement purchase = driver.findElement(By.id("purchase_cash"));
			purchase.click();
		}
		
		@Test(groups= {"Smoke"}) 
		public void test3() {

			driver.findElement(By.linkText("Transfer Funds")).click();
			assertEquals(driver.getTitle(),"Zero - Transfer Funds");
			
			WebElement fromaccount = driver.findElement(By.id("tf_fromAccountId"));
			Select sel1 = new Select(fromaccount);
			sel1.selectByIndex(2);
			
			WebElement toaccount = driver.findElement(By.id("tf_toAccountId"));
			Select sel2 = new Select(toaccount);
			sel2.selectByValue("5");
			
			driver.findElement(By.id("tf_amount")).sendKeys("50");
			driver.findElement(By.id("btn_submit")).click();
			
			WebDriverWait ewait3 = new WebDriverWait(driver, 10);
			ewait3.until(ExpectedConditions.textToBe(By.xpath("(//h2[contains(text(),'Transfer Money & Make Payments - Verify')])"), "Transfer Money & Make Payments - Verify"));
			
			driver.findElement(By.id("btn_submit")).click();
		}
		
		@AfterMethod(alwaysRun= true)
		public void logout() {
			driver.findElement(By.xpath("//i[@class='icon-user']")).click();
			driver.findElement(By.id("logout_link")).click();
		}
		
		@AfterClass(alwaysRun= true)
		public void cleanup() {
		driver.close();
		
		}	
}
