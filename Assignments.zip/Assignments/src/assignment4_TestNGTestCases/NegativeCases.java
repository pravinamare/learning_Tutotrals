package assignment4_TestNGTestCases;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NegativeCases {
	
	public WebDriver driver;
	
	@BeforeClass(alwaysRun= true)
	public void setUp() {
		
		// Set System path for browser driver
		System.setProperty("webdriver.chrome.driver" , "C:\\SeleniumBrowserDrive\\chromedriver.exe");
		
		//Open Browser
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	
		//Open url
		driver.get("http://zero.webappsecurity.com/");
			
		assertEquals(driver.getTitle(),"Zero - Personal Banking - Loans - Credit Cards");
		
		}

	
	//Login check with wrong password
	
	@Test(groups= {"Regression"})
	public void wrongpassword() {
		driver.findElement(By.id("signin_button")).click(); 
		
		driver.findElement(By.name("user_login")).sendKeys("username");  
		driver.findElement(By.id("user_password")).sendKeys("passwrd"); 
		
		driver.findElement(By.name("submit")).click();
		
		String errormsg = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();
		System.out.println(errormsg);
		assertEquals(errormsg,"Login and/or password are wrong.");
	}
		
		
	//Login check with Wrong Username
	
	@Test(groups= {"Regression"})
		public void wrongusername() {
			
			
			driver.findElement(By.name("user_login")).sendKeys("user");  
			driver.findElement(By.id("user_password")).sendKeys("password"); 
			
			driver.findElement(By.name("submit")).click();
			
			String errormsg = driver.findElement(By.xpath("//div[@class='alert alert-error']")).getText();
			System.out.println(errormsg);
			assertEquals(errormsg,"Login and/or password are wrong.");
			
		}
		
		
	// Online banking page heading check
	@Test(enabled = false, priority=2)
		public void onlinebankingtext() {
			driver.findElement(By.id("onlineBankingMenu")).click();
			String header = driver.findElement(By.xpath("//div[@class='row'][2]")).getText();
			System.out.println(header);
			assertEquals(header,"Online Banking.");
			}

@AfterClass
public void cleanup() {
	driver.close();
}



}




