package com.qa.zerobank.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.TestBase.TestBase;

public class Loginpage extends TestBase{
	@FindBy(id="user_login")
	WebElement  id;
	
	@FindBy(id="user_password")
	WebElement pwwd;
	
	@FindBy(name="submit")
	WebElement subitbutton;
	
	@FindBy(id="details-button")
	WebElement detailsbutton;
	
	@FindBy(linkText="Proceed to zero.webappsecurity.com (unsafe)")
	WebElement proceedtolink;
	
	public Loginpage() {
		PageFactory.initElements(driver, this);
	}
	public void loginInvalid(String uid , String pwd) {
		id.sendKeys(uid);
		pwwd.sendKeys(pwd);
		subitbutton.click();
    	//detailsbutton.click();
//		proceedtolink.click();
//		return new AccountSummarypage();
	}
	public AccountSummarypage loginvalid(String uid , String pwd) {
		id.sendKeys(uid);
		pwwd.sendKeys(pwd);
		subitbutton.click();
		detailsbutton.click();
		proceedtolink.click();
		return new AccountSummarypage();
	}
	
	
	
	

}
