package com.qa.TestBase;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class TestBase {

	public static WebDriver driver;
	public static Properties prop;
	
	public TestBase ( ){
		
		prop = new Properties();
		try {
			FileInputStream ip=new FileInputStream(System.getProperty("user.dir")+"\\"+"src\\main\\java\\com\\qa\\zerobank\\config\\config.property");
		      prop.load(ip);
			
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
	        e.printStackTrace();
		}
 }
	
	public static void intialization() {
		
		  String browserName = prop.getProperty("browser");
	       String Path = System.getProperty("user.dir")+"\\"+"src\\main\\resources\\com\\qa\\zerobank\\seleniumbrowserdriver";

		
		     if(browserName.equalsIgnoreCase("chrome")) {

		    	// System.setProperty("webdriver.chrome.driver", Path + "chromedriver.exe");
		    	 System.setProperty("webdriver.chrome.driver", "C:\\Trainingworkspace\\Assignment4POMDesginpattern\\src\\main\\resources\\com\\qa\\zerobank\\seleniumbrowserdriver\\chromedriver.exe");
			            driver = new ChromeDriver();
		   }
	         else if (browserName.equalsIgnoreCase("FireFox")) {
		            System.setProperty("webdriver.gecko.driver", Path + "geckodriver.exe");
			            driver = new FirefoxDriver();
	       }
	        else if (browserName.equalsIgnoreCase("ie"))  { 
	        
		           System.setProperty("webdriver.chrome.driver", Path + "IEDriverServer.exe");
			            driver = new InternetExplorerDriver();
	       }
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
	

}
}


