package com.qa.zerobank.testcase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.TestBase.TestBase;
import com.qa.zerobank.TestUtill.TestUtill;
import com.qa.zerobank.pages.Homepage;
import com.qa.zerobank.pages.Loginpage;


public class HomepageTestcase extends TestBase{
	Homepage homePage;
	Loginpage logInPage;
	TestUtill testutill;
	
	public HomepageTestcase() {
		super();
	}
	
	@BeforeMethod
	public void setUp () {
		intialization();
		homePage = new Homepage();
		logInPage = new Loginpage();
		testutill= new TestUtill();
	}
	
	@AfterMethod
	public void cleanUp () {
		// close driver
		driver.close();
		driver.quit();	
	}
	@Test
    public void validateHomePage() {
		homePage.assertHomePageTitle();
	}
	@Test
	public void signinbutton() {
		logInPage = homePage.clickOnSignInButton();
//		logInPage.assertLogInPageTitle();
}
}
