package com.qa.zerobank.testcase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.TestBase.TestBase;
import com.qa.zerobank.TestUtill.TestUtill;
import com.qa.zerobank.pages.AccountSummarypage;
import com.qa.zerobank.pages.Homepage;
import com.qa.zerobank.pages.Loginpage;

public class AccountsummaryTestcase extends TestBase {
	Homepage homePage;
	Loginpage logInPage;
	AccountSummarypage accountSummaryPage;
	TestUtill testutill;
	String sheetName = "ZerobankNegativetestcasedata";
	
	public AccountsummaryTestcase() {
		super();
	}
	@BeforeMethod
	  public void beforeMethod() {
		  intialization();
			homePage = new Homepage();
			logInPage = new Loginpage();
			accountSummaryPage = new 	AccountSummarypage();
			testutill=new TestUtill();
	  }
	 @AfterMethod
	  public void afterMethod() {
		  
			driver.close();
			driver.quit();
	 }
	 @Test
	 public void Accountsummarypagetestcase() {
		 homePage.clickOnSignInButton();
		 logInPage.loginvalid("username", "password");
		 accountSummaryPage.TransferFund();
		 System.out.println("logout sucessfull--------!!");
	 }
	 
	 
	 }
	 


