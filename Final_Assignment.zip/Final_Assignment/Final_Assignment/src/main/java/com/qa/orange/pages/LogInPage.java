package com.qa.orange.pages;



import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.qa.orange.base.BaseTest;
/**
 * @author Vishnu Raj
 *
 */
public class LogInPage extends BaseTest {
	
	
	@FindBy(id="btnLogin")
	WebElement LoginInButton;

	@FindBy(id="txtUsername")
	WebElement UserName;

	@FindBy(id="txtPassword")
	WebElement Password;

	@FindBy(xpath="//div[@id='divLogo']/img[1]")
	WebElement Logo;

		

	
	public LogInPage() {


		PageFactory.initElements(driver, this);

		}

		public void assertLoginPageTitle() {

		assertEquals(driver.getTitle(), "OrangeHRM", "Mismatch found");

		}
		
		public boolean VerifyLogo() {
			return Logo.isDisplayed();
		}
		public void UsernamePassword() {
			UserName.sendKeys(prop.getProperty("username"));
			Password.sendKeys(prop.getProperty("password"));
		}
		public LogInPage clickOnSignInButton() {
			
			LoginInButton.click();
			return new LogInPage();
		}	}
