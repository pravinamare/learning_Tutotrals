package com.qa.orange.util;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.File;
import java.io.FileInputStream;


import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.qa.orange.base.BaseTest;

public class Testutil extends BaseTest {

	static JavascriptExecutor js;
	Connection con;

	public static String TESTDATA_SHEET_PATH = System.getProperty("user.dir")
			+ "src\\test\\resources\\com\\qa\\zerobank\\testdata\\" + prop.getProperty("testdata");

	static Workbook book;
	static Sheet sheet;

	public static Workbook getWorkbook(String path, String name) throws Exception {
		Workbook wb = null;
		File file = new File(path + "\\" + name);
		FileInputStream inputStream = new FileInputStream(file);
		String fileExtensionName = name.substring(name.indexOf("."));
		try {
			if (fileExtensionName.equals(".xlsx")) {
				wb = new XSSFWorkbook(inputStream);
			} else if (fileExtensionName.equals(".xls")) {
				POIFSFileSystem fs = new POIFSFileSystem(inputStream);
				wb = new HSSFWorkbook(fs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (wb != null) {
				//wb.close();
			}
			if (inputStream != null) {
				inputStream.close();
			}
		}
		return wb;
	}
	public static Sheet getsheetName(String path, String name, int index)
			throws IOException {
		Workbook wb = null;
		Sheet sheet = null;
		File file = new File(path + "\\" + name);
		FileInputStream inputStream = new FileInputStream(file);
		String fileExtensionName = name.substring(name.indexOf("."));
		try {
			if (fileExtensionName.equals(".xlsx")) {
				wb = new XSSFWorkbook(inputStream);
			} else if (fileExtensionName.equals(".xls")) {
				wb = new HSSFWorkbook(inputStream);
			}

			sheet = wb.getSheetAt(index);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (wb != null) {
				//wb.close();
			}
			if (inputStream != null) {
				inputStream.close();
			}
		}

		return sheet;

	}
	public static Object[][] getExcelData(String path, String filename,String sheetname) throws Exception
	{
		Sheet sheet = null;
		int rowCount = 0;
		int colCount =0;
		int index=-1;
		Object[][] excelData = null;
		try {
			index = getWorkbook(path, filename).getSheetIndex(sheetname);
			sheet=getsheetName(path,filename,index);
			rowCount = sheet.getLastRowNum();
			System.out.println("Row Count :- " + rowCount);
			rowCount = sheet.getLastRowNum();
			DataFormatter formatter = new DataFormatter();
			System.out.println("rowCount :" +rowCount);

			int totalCount = 0;
			for (int i = 1; i < rowCount; i++) {
				Row r = sheet.getRow(i);
				colCount = r.getLastCellNum();
				if(formatter.formatCellValue(r.getCell(colCount-1)).equalsIgnoreCase("YES"))
				{
					totalCount=totalCount+1;
				}
			}
			System.out.println("totalCount: "+totalCount);
			excelData = new Object[totalCount][colCount-1];
			int tempNum=0;
			for (int i = 1; i < rowCount; i++) {
				for (int j = 0; j < colCount-1; j++) {
					if(formatter.formatCellValue(sheet.getRow(i).getCell(colCount-1)).equalsIgnoreCase("YES"))
					{

						excelData[tempNum][j] = formatter.formatCellValue(sheet.getRow(i).getCell(j)).trim();
						System.out.print(excelData[tempNum][j] +" ");
					}
				}
				if(formatter.formatCellValue(sheet.getRow(i).getCell(colCount-1)).equalsIgnoreCase("YES"))
				{
					tempNum=tempNum+1;
				}
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}          
		return excelData;
	}
	
	public static void TakeScreenshot(String pageName) {

		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		String homeDir = System.getProperty("user.dir");

		try {
			FileUtils.copyFile(srcFile,
					new File(homeDir + "/screenshots+/" + pageName + System.currentTimeMillis() + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void executeExeFile(String fileName) {

		try {
			Runtime.getRuntime().exec(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void executeJavaScript(String jsQuery) {
		js = (JavascriptExecutor) driver;
		js.executeScript(jsQuery);

	}

//open db connection
	public Connection createDBConnection() throws ClassNotFoundException, SQLException {

//load driver jar class
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("MySQL connection Driver loaded");

//Create connection
		con = DriverManager.getConnection("jdbc:mysql://" + prop.getProperty("dbhost") + ":" + prop.getProperty("port")
				+ "/" + prop.getProperty("dbname"), prop.getProperty("dbuser"), prop.getProperty("dbpassword"));

//con = DriverManager.getConnection("jdbc:mysql://dbhost:port/dbname", dbuser, dbpassword);

		System.out.println("Connected to MySQL DB");

		return con;
	}

//process

	public ResultSet executeDBQuery(Connection con, String query) throws SQLException {
//create statement
		Statement smt = con.createStatement();
//execute query
		ResultSet rs = smt.executeQuery(query);
		System.out.println(rs);
		return rs;
	}
//close db connection

	public void closeConnection(Connection con) throws SQLException {
		con.close();

	}
}